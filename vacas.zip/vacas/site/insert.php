<?php

include 'bd_controller_local.php';

$u = mysqli_real_escape_string($conn, $_REQUEST['nom']);
$t = mysqli_real_escape_string($conn, $_REQUEST['temp']);
$h = mysqli_real_escape_string($conn, $_REQUEST['hum']);
$l = mysqli_real_escape_string($conn, $_REQUEST['lati']);
$lo = mysqli_real_escape_string($conn, $_REQUEST['longi']);
$a = mysqli_real_escape_string($conn, $_REQUEST['alti']);
$p = mysqli_real_escape_string($conn, $_REQUEST['pas']);
$la = mysqli_real_escape_string($conn, $_REQUEST['latidos']);

if  ($conn->connect_error)
{
    die("Error:".$conn->connect_error);
}
//aqui es donde vamos a insertar los dtos, y se ponen los campos que hay en la tabla
$sql = "INSERT INTO Vacas (IDRegistros, IDDispositivo, Fecha, Temp,  Hum, Lati, Longi, Alti, Pas, Latidos) values (NULL, '$u', now(), '$t', '$h', '$l',  '$lo' , '$a', '$p' , '$la')";

 
//= asignacion == comparat === validacion
if($conn->query($sql) === TRUE)
{
    echo "agregado correctamente";
}
else
{
    echo "Error:".$sql."<br>".$conn->error;
}

$conn->close();
?>

