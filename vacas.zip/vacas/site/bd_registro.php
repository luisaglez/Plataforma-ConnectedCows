<?php
$servidor ="localhost";
$usuario = "root";
$pass="";
$base="usuarios";
$conn = new mysqli($servidor, $usuario, $pass, $base);
?>