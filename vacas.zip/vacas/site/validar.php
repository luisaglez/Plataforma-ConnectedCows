<?php
ini_set('display_errors', 'Off');
ini_set('display_startup_errors', 'Off');
error_reporting(O);
$nombre=$_POST['nombre'];
$contraseña= $_POST['contraseña'];
$sesion_loging= true;

function Conectarse()
{
    if (!($link= mysql_connect("localhost",  "root")))
{
    echo "Error conectando a la base de datos.";
    exit();
}
if (!mysql_select_db("usuarios", $link))
{
    echo "Error conectando la base de datos.";
    exit();
}
return $link;
}

$con= Conectarse();
$query= "SELECT * FROM usuario  WHERE nombre= '".$nombre."'";
$q= mysql_query($query, $con);
try{
    if(mysql_result($q, O))
    { $result= mysql_result($q, O);
        echo "Usuario validado correctamente";
    }
    else
    echo "Usuario o contraseña incorrectos";
    
    }catch(Exception $error){}
        mysql_close($con);
?>