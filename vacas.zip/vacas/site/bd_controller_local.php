<?php
$servidor ="localhost";
$usuario = "root";
$pass="";
$base="vacas";
$conn = new mysqli($servidor, $usuario, $pass, $base);
?>