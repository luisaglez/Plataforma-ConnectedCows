<?php

include 'database.php';

$nombre=$_POST['nombre'];
$contraseña= $_POST['contraseña'];


if  ($conn->connect_error)
{
    die("Error:".$conn->connect_error);
}
//aqui es donde vamos a insertar los dtos, y se ponen los campos que hay en la tabla
$sql = "INSERT INTO usuario (nombre, contraseña) values ( '$nombre', '$contraseña')";

 
//= asignacion == comparat === validacion
if($conn->query($sql) === TRUE)
{
    echo "agregado correctamente";
}
else
{
    echo "Error:".$sql."<br>".$conn->error;
}

$conn->close();
?>

