<?php
	$conexion = new mysqli("localhost","root","","vacas");
	$consultar ="SELECT * FROM `registros` WHERE IDDispositivo=2";
	$query= mysqli_query($conexion, $consultar);
	$array=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
	<head>
</head>
<body>
<nav style= "background-color:#00796b;">
		<center>
			<h1 style ="color:white;"> Pasos del PARDO SUIZO</h1>
</center>
</nav>
<center>
	<table class= "table">
		<thead class= "thead-dark">
			<tr>
				<th scope= "col">IDRegistro</th>
				<th scope= "col">IDDispositivo</th>
				<th scope= "col">Fecha</th>
				<th scope= "col">Pasos</th>
</tr>
</thead>
<tbody id="datos">
	<?php
	foreach($query as $row) {?>
		<tr>
		<td><?php echo $row ['IDRegistro'];?> </td>
		<td><?php echo $row ['IDDispositivo'];?> </td>
		<td><?php echo $row ['Fecha'];?> </td>	
		<td><?php echo $row ['Valor'];?> </td>	
</tr>
	</tbody>
	<?php
	}
	?>
</table>
</center>
</body>
	</html>